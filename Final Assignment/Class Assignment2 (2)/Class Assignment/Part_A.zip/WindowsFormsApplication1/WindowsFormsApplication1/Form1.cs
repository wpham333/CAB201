﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1 {
    public partial class Form1 : Form {

        enum GameButton { Coin, Dice, Card };
        GameButton whichOptions;

        public Form1() {
            InitializeComponent();
            startButton.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e) {
            if (coinRadioButton.Checked) {
                whichOptions = GameButton.Coin;
                Form Form1 = new Two_Up();
                Form1.Show();
            } else if (diceRadioButton.Checked) {
                whichOptions = GameButton.Dice;
                Form Form1 = new Which_Dice_Game();
                Form1.Show();
            } else if (cardRadioButton.Checked) {
                whichOptions = GameButton.Card;
                Form Form1 = new Which_Card_Game();
                Form1.Show();
            }


        }

        private void button2_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void threeButton_CheckedChanged(object sender, EventArgs e) {
            startButton.Enabled = true;
        }

    }
}
